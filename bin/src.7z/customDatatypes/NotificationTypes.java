package customDatatypes;

public enum NotificationTypes {
	EMAIL, CELLPHONE, PIGEON_POST
}

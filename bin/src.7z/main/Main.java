package main;

import userOperations.*;
import authenticatedUsers.LoggedInAuthenticatedUser;

public class Main
{
	public static void main(String args[])
	{	
		Operations op;
		LoggedInAuthenticatedUser user;
		
		LoginOperation lo = new LoginOperation();
		user = lo.login();
		op = new ServerStart();
		op.execute(user);

		user = lo.login();
		op = new EnrollInCourse();
		op.execute(user);

		user = lo.login();
		op = new AddMark();
		op.execute(user);
	}
}
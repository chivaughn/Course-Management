package systemUsers;

public interface IAdminModel extends SystemUserModel {
	
}

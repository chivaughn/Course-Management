package systemUsers;

public interface SystemUserModel extends SystemUser {

}

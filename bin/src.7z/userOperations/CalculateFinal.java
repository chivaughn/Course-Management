package userOperations;

import java.util.Scanner;
import authenticatedUsers.LoggedInAuthenticatedUser;
import offerings.CourseOffering;
import offerings.ICourseOffering;
import systemUsers.InstructorModel;
import systemUsers.StudentModel;
import server.Server;

public class CalculateFinal implements Operations{
	
	public void execute(LoggedInAuthenticatedUser user)
	{
		if(Server.getInstance().getState().equals("OFF"))
		{
			System.out.println("Operation unavailable - server is stopped");
		}
		else
		{
			if(user.getAuthenticationToken().getUserType().equals("Instructor"))
			{
				InstructorModel instructor = (InstructorModel)user.getModel();
				ICourseOffering course = new CourseOffering();
				StudentModel student = new StudentModel();
		
				Scanner scan = new Scanner(System.in);
		
				System.out.println("For which course do you want to calculate the final mark? Enter the course ID");
				String courseID = scan.nextLine();
				for(ICourseOffering c : instructor.getIsTutorOf()){
					if(c.getCourseID().equals(courseID)){
						course = c;
					}
					else{
						System.out.println("You are not allowed to calculate the final mark for this course.");
					}
				}
		
				System.out.println("For which student do you want to calculate the final mark? Enter the student ID.");
				String studentID = scan.nextLine();
				for(StudentModel s : course.getStudentsEnrolled()){
					if(s.getID().equals(studentID)){
						student = s;
					}
					else{
						System.out.println("You are not allowed to calculate the final mark for this student in the course " + course.getCourseName() +".");
					}
				}
				scan.close();
				
				System.out.println(((CourseOffering)course).calculateFinalGrade(student.getID()));
			}
			else
			{
				System.out.println("This operation is unavailable to your user type.");
			}
		}
	}
}

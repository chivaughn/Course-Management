package userOperations;

import java.util.Map;
import java.util.Scanner;
import authenticatedUsers.LoggedInAuthenticatedUser;
import customDatatypes.Marks;
import offerings.CourseOffering;
import offerings.ICourseOffering;
import systemUsers.InstructorModel;
import systemUsers.StudentModel;
import server.Server;

public class ModifyMark implements Operations {

	public void execute(LoggedInAuthenticatedUser user)
	{
		if(Server.getInstance().getState().equals("OFF"))
		{
			System.out.println("Operation unavailable - server is stopped");
		}
		else
		{
			if(user.getAuthenticationToken().getUserType().equals("Instructor"))
			{
				InstructorModel instructor = (InstructorModel)user.getModel();
				ICourseOffering course = new CourseOffering();
				StudentModel student = new StudentModel();
				String examOrAssignment = null;
				Double mark = 0.0;
		
				Scanner scan = new Scanner(System.in);
		
				System.out.println("For which course do you want to modify the mark? Enter the course ID");
				String courseID = scan.nextLine();
				for(ICourseOffering c : instructor.getIsTutorOf()){
					if(c.getCourseID().equals(courseID)){
						course = c;
					}
					else{
						System.out.println("You are not allowed to modify a mark for this course.");
					}
				}
		
		
				System.out.println("For which student do you want to modify the mark? Enter the student ID.");
				String studentID = scan.nextLine();
				for(StudentModel s : course.getStudentsEnrolled()){
					if(s.getID().equals(studentID)){
						student = s;
					}
					else{
						System.out.println("You are not allowed to modify a mark for this student in the course " + course.getCourseName() +".");
					}
				}
		
				System.out.println("For which evaluation strategy of this course do you want to modify the mark?");
				examOrAssignment = scan.nextLine();
		
				System.out.println("Enter the new mark for course "+ course.getCourseName()+" ,student " +student.getName() +" " + student.getSurname() + ", evaluation strategy "+examOrAssignment + ".");
				mark = scan.nextDouble();
		
				scan.close();
		
				Map<ICourseOffering, Marks> currentMarks = student.getPerCourseMarks();
				Marks m = currentMarks.get(course);
				m.initializeIterator();
				while(m.hasNext()){
					if(m.getCurrentKey() == examOrAssignment){
						m.setCurrentValue(mark);
					}
				}
				currentMarks.put(course,m);
				student.setPerCourseMarks(currentMarks);
			}
			else
			{
				System.out.println("This operation is unavailable to your user type.");
			}
		}
	}
}
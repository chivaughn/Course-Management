package userOperations;

import java.util.Scanner;
import authenticatedUsers.LoggedInAuthenticatedUser;
import offerings.CourseOffering;
import offerings.ICourseOffering;
import systemUsers.InstructorModel;
import systemUsers.StudentModel;
import server.Server;

public class PrintClassRecord implements Operations{

	public void execute(LoggedInAuthenticatedUser user)
	{
		if(Server.getInstance().getState().equals("OFF"))
		{
			System.out.println("Operation unavailable - server is stopped");
		}
		else
		{
			if(user.getAuthenticationToken().getUserType().equals("Instructor"))
			{
				InstructorModel instructor = (InstructorModel)user.getModel();
				ICourseOffering course = new CourseOffering();
		
				Scanner scan = new Scanner(System.in);
		
				System.out.println("For which course do you want to print the class record? Enter the course ID");
				String courseID = scan.nextLine();
				for(ICourseOffering c : instructor.getIsTutorOf()){
					if(c.getCourseID().equals(courseID)){
						course = c;
					}
					else{
						System.out.println("You are not allowed to print the class record for this course.");
					}
				}
				System.out.println("Class record for course "+ course.getCourseID()+" "+ course.getCourseName());
				for(StudentModel sm : course.getStudentsEnrolled()){
					System.out.println(sm.getID()+ "\t" + sm.getName() +" "+ sm.getSurname() + "\t"+ sm.getEvaluationEntities().get(course)+"\n" 
							+ sm.getPerCourseMarks().get(course).toString());
				}
				
				scan.close();
			}
			else
			{
				System.out.println("This operation is unavailable to your user type.");
			}
		}
	}
}

package userOperations;

import java.util.Scanner;
import authenticatedUsers.LoggedInAuthenticatedUser;
import offerings.ICourseOffering;
import systemUsers.StudentModel;
import server.Server;

public class PrintRecord implements Operations{

	public void execute(LoggedInAuthenticatedUser user)
	{
		if(Server.getInstance().getState().equals("OFF"))
		{
			System.out.println("Operation unavailable - server is stopped");
		}
		else
		{
			if(user.getAuthenticationToken().getUserType().equals("Instructor"))
			{
				StudentModel student = (StudentModel)user.getModel();
				System.out.println("What is the course ID of the course where you want to print your records for?");
				Scanner scan = new Scanner(System.in);
				String courseID = scan.nextLine();
				for(ICourseOffering c: student.getCoursesEnrolled()){
					if(c.getCourseID().equals(courseID)){
						ICourseOffering course = c;
						System.out.println(student.getPerCourseMarks().get(course).toString());
					}
					else{
						System.out.println("You are not enrolled in this course.");
					}
				}
				scan.close();
			}
			else
			{
				System.out.println("This operation is unavailable to your user type.");
			}
		}
	}
}
